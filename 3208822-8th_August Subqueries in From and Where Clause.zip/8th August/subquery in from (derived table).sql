
select * from myemp;

-- Retrieve employee whose bonus > 1000

Select *,salary * 0.2 as Bonus from myemp
	where bonus > 1000;
    
-- Derived table 
-- using subquery in from Clause
Select * from (Select *,salary *0.2 as Bonus
					from myemp) s
		where bonus > 2000;
        
-- Retrieve employee with largest Full_name
select *,length(full_name) as len_ from 
(Select *,Concat(first_name," ",last_name) as full_name
	from myemp) as s1
    order by len_ desc;
    
/* Calculate Bonus(salary *0.2) 
Filter employee bonus > 2000
Calculate total_salary (bonus +salary) 
Filter employee total_salary > 20000
deducte 5% from the employees whose total_salary > 20000    
Filter employee whose final_salary >20000*/


select * from (select *,total_salary - total_salary *0.05 as final_salary  from (select *,salary +bonus as total_salary
 from (Select *, salary *0.2 as bonus from myemp) s
		where bonus > 2000) s1
        where total_salary > 20000) s2
        where final_salary > 20000;

    
-- CTE (Common table expression)
-- Using CTE will be able create derived tables in structed way

with cte_1 as (select *,salary *0.2 as Bonus from myemp),

cte_2 as (Select *,salary +Bonus as total_salary from cte_1
	where bonus > 2000),
    
cte_3 as (Select *,total_salary - total_salary *0.05 as final_salary from cte_2
	where total_salary > 20000)

Select * from cte_3
	where final_salary > 20000;
    
Select * from members;









        
