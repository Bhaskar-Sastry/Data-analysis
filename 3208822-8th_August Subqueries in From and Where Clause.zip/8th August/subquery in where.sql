

Select * from movies;
Select * from members;

-- Retrieve movies which are rented so far
-- Where Clause
-- using subquery for a Condition

Select * from movies
	where ID in (Select movieid from members);
    
-- not rented
Select * from movies
	where ID not in (Select ifnull(movieid,0) from members);
    
    
-- Retrieve employees whose salary > avgerage salary 

Select * from myemp
	where salary > (select avg(salary) from myemp);
    
    
use salesdb;
show tables;

Select * from customers;

-- Retrieve products brought by jane.
-- Retrive the products where price is greater than avg price.


Select * from products
	where product_id IN (Select Product_id from order_items
							where order_id IN (Select order_id from orders
												where customer_id = (Select customer_id
																		from customers
																			where first_name = "jane")));




