
-- Window Functions

Select * from myemp;

Select dep_id,Avg(salary) from myemp
	group by dep_id;

/*Retrieve employee whose salary is greater than avg salary of 
their respective department*/
-- Over Clause
with cte_1 as (Select *,Avg(salary) over(partition by dep_id) as d_avg
	from myemp),
    
cte_2 as (Select *, salary - d_avg as diff from cte_1)

Select * from cte_2
	where diff > 0;
    
    
-- Calculate cummulative salary WRT emp_id 

Select * from myemp;

Select *,sum(salary) over(order by emp_id ) as cummulative_sum
from myemp;
-- Calculate cummulative salary WRT emp_id and dep_id
Select *,sum(salary) over(partition by dep_id order by emp_id ) as cummulative_sum
from myemp;



-- Ranking Function
Select * from scores;

Select *,Rank() over(order by marks desc) as rank_f,
Dense_rank() over(order by marks desc) as dense_f,
Row_number() over(order by marks desc) as row_f
from scores;

-- Retrieve 2nd highest salaried employee
Select * from myemp
	order by salary desc
    limit 1 offset 1;

with cte_1 as (Select *,dense_rank() over(order by salary desc) as drnk
	from myemp)
select * from cte_1
	where drnk = 2;
    
-- Retrieve highest salaried employee from each department

with cte_1 as (Select *, dense_rank() over(partition by dep_id order by salary desc) as drnk
from myemp)
select * from cte_1 
	where drnk = 1;
    
-- Retrieve employees who hired 2nd in each department

with cte_1 as (Select *, dense_rank() over(partition by dep_id order by hire_date ) as drnk
from myemp)
select * from cte_1 
	where drnk = 2;
    
-- Value Functions
/* lag -- Before
 lead -- After*/
 
 Select * from salesdata;

Select *,lag(sale_amount) over(order by sale_date) as lag_val,
	lead(sale_amount) over(order by sale_date) as lead_val from salesdata;
    
-- Difference of sales WRT pervious day sale

with cte_1 as (Select *,lag(sale_amount) over(order by sale_date) as lag_val
	from salesdata),

cte_2 as (Select *,sale_amount - lag_val as diff from cte_1)

select * from cte_2
	where diff < 0;




    
    
    
    