
-- Subquery in Select 
Select * from mobiles;
Select * from peopledata;

Select Avg(price) as Average_price,
	(Select avg(purchase_amount) from peopledata) as average_amount
    from mobiles;
    
-- Subquery in Joins

select emp_id,s.first_name,salary_cat from myemp
Inner JOIN 
(Select *, (Case 
			when salary > 15000 then "High"
            when salary between 10000 and 15000 then "Average"
            else "Low" END) as salary_cat
            from myemp) as s
		using(emp_id);
        
        
        
        