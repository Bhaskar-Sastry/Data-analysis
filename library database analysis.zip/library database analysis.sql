CREATE DATABASE library_db;
USE library_db;
CREATE TABLE Book (
    BookID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    PublisherName VARCHAR(200)
);
CREATE TABLE Book_Authors (
    AuthorID INT(11) AUTO_INCREMENT PRIMARY KEY,
    BookID INT(11),
    AuthorName VARCHAR(200) NOT NULL,
    CONSTRAINT fk_bookauthors_book
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE Library_Branch (
    BranchID INT AUTO_INCREMENT PRIMARY KEY,
    BranchNameborrower VARCHAR(100) NOT NULL,
    Address VARCHAR(200)
);
CREATE TABLE Book_Copies (
    CopyID INT AUTO_INCREMENT PRIMARY KEY,
    BookID INT,
    BranchID INT,
    No_Of_Copies INT NOT NULL,
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (BranchID) REFERENCES Library_Branch(BranchID)
    ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE Borrower (
    CardNo INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(200) NOT NULL,
    Address VARCHAR(300),
    Phone VARCHAR(20)
);
CREATE TABLE Book_Loans (
    LoanID INT AUTO_INCREMENT PRIMARY KEY,
    BookID INT,
    BranchID INT,
    CardNo INT,
    DateOut DATE,
    DueDate DATE,
    FOREIGN KEY (BookID) REFERENCES Book(BookID)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (BranchID) REFERENCES Library_Branch(BranchID)
    ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (CardNo) REFERENCES Borrower(CardNo)
    ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE Publisher (
    PublisherID INT AUTO_INCREMENT PRIMARY KEY,
    PublisherName VARCHAR(200) NOT NULL UNIQUE,
    Address VARCHAR(300),
    Phone VARCHAR(20)
);

select * from book;
select * from book_authors;
select * from book_copies;
select * from book_loans;
select * from borrower;
select * from library_branch;
select * from publisher;
/* 1. How many copies of "The Lost Tribe" are owned by "Sharpstown" branch?*/
SELECT bc.No_Of_Copies
FROM Book b
JOIN Book_Copies bc ON b.BookID = bc.BookID
JOIN Library_Branch lb ON bc.BranchID = lb.BranchID
WHERE b.Title = 'The Lost Tribe'
AND lb.BranchName = 'Sharpstown';
/*2. How many copies of "The Lost Tribe" are owned by each branch?*/
SELECT lb.BranchName, bc.No_Of_Copies
FROM Book b
JOIN Book_Copies bc ON b.BookID = bc.BookID
JOIN Library_Branch lb ON bc.BranchID = lb.BranchID
WHERE b.Title = 'The Lost Tribe';
/*3. Borrowers who do not have any books checked out*/
SELECT br.Name
FROM Borrower br
LEFT JOIN Book_Loans bl ON br.CardNo = bl.CardNo
WHERE bl.LoanID IS NULL;
/*4. Books loaned from Sharpstown, DueDate = 02-03-2018*/
SELECT b.Title, br.Name, br.Address
FROM Book_Loans bl
JOIN Book b ON bl.BookID = b.BookID
JOIN Borrower br ON bl.CardNo = br.CardNo
JOIN Library_Branch lb ON bl.BranchID = lb.BranchID
WHERE lb.BranchName = 'Sharpstown'
AND bl.DueDate = '2018-02-03';
/*5. For each library branch, total number of books loaned out*/
SELECT lb.BranchName, COUNT(bl.LoanID) AS TotalBooksLoaned
FROM Library_Branch lb
LEFT JOIN Book_Loans bl ON lb.BranchID = bl.BranchID
GROUP BY lb.BranchName;
/*6. Borrowers with more than 5 books checked out*/
SELECT br.Name, br.Address, COUNT(bl.LoanID) AS BooksCheckedOut
FROM Borrower br
JOIN Book_Loans bl ON br.CardNo = bl.CardNo
GROUP BY br.CardNo, br.Name, br.Address
HAVING COUNT(bl.LoanID) > 5;
/*7. Books by Stephen King & copies owned by Central branch*/
SELECT b.Title, bc.No_Of_Copies
FROM Book b
JOIN Book_Authors ba ON b.BookID = ba.BookID
JOIN Book_Copies bc ON b.BookID = bc.BookID
JOIN Library_Branch lb ON bc.BranchID = lb.BranchID
WHERE ba.AuthorName = 'Stephen King'
AND lb.BranchName = 'Central';