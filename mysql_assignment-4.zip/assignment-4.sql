-- 1. Create Database
CREATE DATABASE IF NOT EXISTS CompanyDB;
USE CompanyDB;

-- 2. Create Employees Table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(15) UNIQUE NOT NULL,
    HireDate DATE NOT NULL,
    JobTitle VARCHAR(50) NOT NULL,
    Department VARCHAR(50) NOT NULL,
    Salary DECIMAL(10,2) CHECK (Salary > 0),
    Status ENUM('Working', 'Old Employee') DEFAULT 'Working'
);

-- 3. Insert Records (Sample Data)
INSERT INTO Employees (FirstName, LastName, Email, PhoneNumber, HireDate, JobTitle, Department, Salary, Status) VALUES
('John', 'Doe', 'john.doe@example.com', '9876543210', '2020-05-10', 'Manager', 'HR', 60000, 'Working'),
('Jane', 'Smith', 'jane.smith@example.com', '9876543211', '2019-03-15', 'Developer', 'IT', 55000, 'Working'),
('Robert', 'Brown', 'robert.brown@example.com', '9876543212', '2018-07-20', 'Analyst', 'Finance', 48000, 'Old Employee'),
('Emily', 'Davis', 'emily.davis@example.com', '9876543213', '2021-01-25', 'Developer', 'IT', 52000, 'Working'),
('Michael', 'Wilson', 'michael.wilson@example.com', '9876543214', '2017-09-30', 'HR Executive', 'HR', 45000, 'Old Employee'),
('Sarah', 'Miller', 'sarah.miller@example.com', '9876543215', '2020-11-10', 'Accountant', 'Finance', 50000, 'Working'),
('David', 'Taylor', 'david.taylor@example.com', '9876543216', '2019-06-05', 'Manager', 'Sales', 70000, 'Working'),
('Laura', 'Anderson', 'laura.anderson@example.com', '9876543217', '2016-02-14', 'Support', 'IT', 40000, 'Old Employee'),
('Daniel', 'Thomas', 'daniel.thomas@example.com', '9876543218', '2022-04-18', 'Intern', 'HR', 30000, 'Working'),
('Olivia', 'Harris', 'olivia.harris@example.com', '9876543219', '2023-08-01', 'Developer', 'Finance', 58000, 'Working');

-- ===============================
-- SET OPERATIONS
-- 1. Unique departments from both Working and Old Employees
SELECT Department FROM Employees WHERE Status = 'Working'
UNION
SELECT Department FROM Employees WHERE Status = 'Old Employee';

-- 2. All job titles (with duplicates) from HR and IT
SELECT JobTitle FROM Employees WHERE Department = 'HR'
UNION ALL
SELECT JobTitle FROM Employees WHERE Department = 'IT';

-- 3. Combine first names from HR and Finance, removing duplicates
SELECT FirstName FROM Employees WHERE Department = 'HR'
UNION
SELECT FirstName FROM Employees WHERE Department = 'Finance';

-- 4. Job titles in either Working or Old Employees
SELECT JobTitle FROM Employees WHERE Status = 'Working'
UNION
SELECT JobTitle FROM Employees WHERE Status = 'Old Employee';

-- ===============================
-- DERIVED TABLES
-- 1. Avg salary per department > 50000
SELECT Department, AvgSalary FROM (
    SELECT Department, AVG(Salary) AS AvgSalary
    FROM Employees
    GROUP BY Department
) AS dept_avg
WHERE AvgSalary > 50000;

-- 2. Hires per year > 10
SELECT HireYear, TotalHires FROM (
    SELECT YEAR(HireDate) AS HireYear, COUNT(*) AS TotalHires
    FROM Employees
    GROUP BY YEAR(HireDate)
) AS year_count
WHERE TotalHires > 10;

-- 3. Departments with more than 3 employees
SELECT Department, EmpCount FROM (
    SELECT Department, COUNT(*) AS EmpCount
    FROM Employees
    GROUP BY Department
) AS dept_count
WHERE EmpCount > 3;

-
-- CTEs
-- 1. Total salary per department > 200000
WITH DeptTotal AS (
    SELECT Department, SUM(Salary) AS TotalSalary
    FROM Employees
    GROUP BY Department
)
SELECT * FROM DeptTotal WHERE TotalSalary > 200000;

-- 2. Hires per year > 3
WITH YearHires AS (
    SELECT YEAR(HireDate) AS HireYear, COUNT(*) AS TotalHires
    FROM Employees
    GROUP BY YEAR(HireDate)
)
SELECT * FROM YearHires WHERE TotalHires > 3;

-- 3. Avg salary per hire year > 50000
WITH YearAvgSalary AS (
    SELECT YEAR(HireDate) AS HireYear, AVG(Salary) AS AvgSalary
    FROM Employees
    GROUP BY YEAR(HireDate)
)
SELECT * FROM YearAvgSalary WHERE AvgSalary > 50000;

-- 4. Departments with more than 2 employees
WITH DeptCount AS (
    SELECT Department, COUNT(*) AS EmpCount
    FROM Employees
    GROUP BY Department
)
SELECT * FROM DeptCount WHERE EmpCount > 2;

-- 5. Statuses with less than 5 employees
WITH StatusCount AS (
    SELECT Status, COUNT(*) AS EmpCount
    FROM Employees
    GROUP BY Status
)
SELECT * FROM StatusCount WHERE EmpCount < 5;
