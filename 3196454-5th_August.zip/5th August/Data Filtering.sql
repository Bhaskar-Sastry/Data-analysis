Select * from myemp;
-- 1st row
Select * from myemp limit 1 offset 0;
-- 2nd row
Select * from myemp limit 1 offset 1;
-- 49th row
Select * from myemp limit 1 offset 48;

-- Column indexing
Select * from myemp;
-- first_name column
Select first_name from myemp;
-- salary column
Select salary from myemp;

-- Slicing (multiple row/col)

-- 1- 5 rows
Select * from myemp limit 5 offset 0;
-- 5th - 10th rows
Select * from myemp limit 6 offset 4;
-- 41 - 50 rows
Select * from myemp limit 10 offset 40;

-- Column slicing
Select first_name,last_name,salary from myemp;

-- Access 100th row
Select * from myemp limit 1 offset 99;
-- Access dep_id column
Select  dep_id from myemp;
-- Access rows from 10 - 31 
Select * from myemp limit 22 offset 9;
-- Access columns first_name and salary and rows 10 -20
Select first_name, salary from myemp
	limit 11 offset 9;
    
    




