use learndb;

show tables;

Select * from myemp;

-- Data Exploration

Describe myemp;

-- How many records are they
Select count(*) from myemp;

-- Null values
Select * from myemp
	where first_name is null;
    
Select * from myemp
	where first_name is not null;
    
-- Unique departments
Select * from myemp;

-- District 
-- Unique values
Select distinct dep_id from myemp;

-- no.of unique values
Select count(Distinct Dep_id) from myemp;

-- Duplicates
Select Distinct * from myemp;

with cte_1 as (Select Distinct * from myemp)
Select count(*) from cte_1;

-- frequency of a column
Select * from myemp;

-- Find out no.of employees workin of each dep
Select dep_id, count(*)  from myemp
	group by dep_id;
    
-- Descriptive statistics of a column
Select min(salary) as min_salary,
	max(salary) as max_salary,
    avg(salary)as avg_salary,
    std(salary) as std_salary,
    variance(salary) as var_salary
    from myemp;
    
-- Entire data
Select * from myemp;
-- Top 5
Select * from myemp
	LIMIT 15;





