
-- Where Clause

Select * from myemp;

-- Retrieve the employees whose salary > 20000
Select * from myemp
	where salary > 20000;

-- Find out no.of employees whose salary > 20000
Select count(*) from myemp
	where salary > 20000;

/*retrieve emp whose salary > 10k and departemnet 
are 40,50,80*/

Select * from myemp
	where salary > 10000 AND dep_id IN (40,50,80);
    
Select * from myemp
	where salary > 1000 AND (dep_id = 40 or
    dep_id = 50 OR dep_id = 80);
    
Select * from peopledata;

-- Retrive custmore name whose purchase amount is > 50000
Select Name from peopledata	
	where purchase_amount > 50000;
    
-- 1. Find out no.of customers who are non-subscribed

/*2. Find out no.of customers whose purchase > 50000 
and gender is Female or is_subscribed is 0*/

-- 3. Find out no.of purchases made after 2023-03-15

/* 4. Retrieve customers whose age > 30 and rating is above 3
and amount > 50000 and reg_date is after 2023-03-15*/

-- 5. count no.of null values in rating column


-- Pattern condition 

-- Like 

/* Wild Cards
-- % (n no.of occurance)
-- _ (single occurance) */
Select * from peopledata;
-- Retrive customers whose name is starting with "T"
Select * from peopledata
	where name Like "T%";
-- Retrieve customers whose name is starting "M" and ending "i"
Select * from peopledata	
	where name like "M%i";
    
/*Retrieve customers whose name is starting with "B" and 
belongs to Telangana*/
Select * from peopledata	
	where name like "B%" AND address Like "%Telangana";

-- Regexp
Select * from peopledata
	where name regexp "^[MBN]";
    
Select * from peopledata
	where name regexp "[ai]$";
    
Select * from peopledata
	where name regexp "[ai]$" AND name Regexp "^[MB]";





