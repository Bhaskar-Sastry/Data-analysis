use learndb;

Select * from authors;
Select * from books;

-- Retrieve authors who have wirtten atleast 1 book
-- Common values(INNER JOIN)
Select Distinct name from authors
	INNER JOIN BOoks
    Using (authorid);
    
-- Retrieve the authors who have not written any book
Select name from authors
	LEFT JOIN books
    using (authorid)
    where bookid is null;


Select * from movies;
Select * from members;



-- Retrieve movies which are rented so far?
Select * from movies
	INNER JOIN members
    on movies.id = members.movieid;
    
-- Retrieve movies which have not rented?

Select * from movies
	LEFT JOIN members
    on movies.id = members.movieid
    where memid is null;
    
    
Select * from meals;
Select * from drinks;

-- Cross JOIn

Select mealname,drinkname,
meals.rate +drinks.rate as total_bill
from meals
CROSS JOIN drinks
order by mealname;


-- Self JOIN

Select * from myemp;

Select * from myemp as e
	INNER JOIN myemp as m
    on e.emp_id = m.mgr_id;




 


