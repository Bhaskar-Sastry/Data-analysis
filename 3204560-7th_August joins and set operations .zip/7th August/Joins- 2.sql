Use grocery_store;
Show tables;
Select * from supplier;
Select * from products;
Select * from categories;
Select * from employees;
Select * from orders;
Select * from order_details;


-- Retrieve products supplied from sai
Select * from products
	INNER join supplier
    using (sup_id)
    where sup_name = "Sai ";
    
-- What is avg total bill of each category

Select cat_name,Avg(total_price) as average_price
 from products
	Inner join categories
    using (cat_id)
    INNER JOIn order_details
    using (prod_id)
    Group by cat_name;
    
    
Select prod_name from customers
	INNER join orders
    using (cust_id)
    INNER join order_details
    using (ord_id)
    INNER JOIn products
    using (prod_id)
    where cust_name = "Aditi Shetty";
    
Select * from customers;





