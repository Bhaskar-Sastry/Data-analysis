
-- Set operations

-- UNION
-- UNION ALL
use learndb;
Select * from students;
Select * from students1;

Select * from students
	UNION ALL
Select * from students1;


Select * from students
	Intersect
Select * from students1;
