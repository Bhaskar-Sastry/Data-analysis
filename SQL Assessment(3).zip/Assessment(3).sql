CREATE DATABASE CompanyDB;
USE CompanyDB;

CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL UNIQUE,
    Location VARCHAR(100) NOT NULL,
    Status ENUM('Active','Inactive') DEFAULT 'Active'
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(15) UNIQUE,
    HireDate DATE NOT NULL,
    JobTitle VARCHAR(100) NOT NULL,
    DepartmentID INT,
    Salary DECIMAL(10,2) CHECK (Salary > 0),
    Status ENUM('Working','Old Employee') DEFAULT 'Working',
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);


INSERT INTO Department (DepartmentID, DepartmentName, Location, Status) VALUES
(1, 'HR', 'New York', 'Active'),
(2, 'Sales', 'Chicago', 'Active'),
(3, 'IT', 'San Francisco', 'Active'),
(4, 'Marketing', 'Boston', 'Inactive'),
(5, 'Finance', 'Dallas', 'Active');

INSERT INTO Employees
(EmployeeID, FirstName, LastName, Email, PhoneNumber, HireDate, JobTitle, DepartmentID, Salary, Status) VALUES
(101, 'Kavya', 'Reddy', 'kavya23@example.com', 9876543210, '2015-03-15', 'HR Manager', 1, 60000, 'Working'),
(102, 'Karthika', 'Sharma', 'karthika32@example.com', 9876543211, '2017-06-20', 'Recruiter', 1, 45000, 'Working'),
(103, 'Sravya', 'Kumar', 'sravya22@example.com', 9876543212, '2016-09-10', 'Accountant', 2, 55000, 'Working'),
(104, 'Sarika', 'Mehta', 'sarika98@example.com', 9876543213, '2018-01-25', 'Financial Analyst', 2, 52000, 'Working'),
(105, 'Poojitha', 'Patel', 'pooja45@example.com', 9876543214, '2014-05-05', 'IT Manager', 3, 75000, 'Old Employee'),
(106, 'Vydehi', 'Naidu', 'vyd67@example.com', 9876543215, '2020-07-19', 'Software Engineer', 3, 68000, 'Working'),
(107, 'Sathish', 'Verma', 'sathish66@example.com', 9876543216, '2019-10-10', 'Marketing Specialist', 4, 48000, 'Working'),
(108, 'Kalpana', 'Mishra', 'kalpana90@example.com', 9876543217, '2013-04-12', 'Operations Manager', 5, 64000, 'Old Employee'),
(109, 'Bhavani', 'Rao', 'bhav433@example.com', 9876543218, '2016-11-30', 'Business Analyst', 2, 53000, 'Working'),
(110, 'Bhargav', 'Singh', 'bhargav87@example.com', 9876543219, '2021-08-15', 'Intern', NULL, 30000, 'Working');


--  Employee with highest salary
SELECT * FROM Employees
WHERE Salary = (SELECT MAX(Salary) FROM Employees);

--  Avg salary in same dept as 'Kavya'
SELECT AVG(Salary) AS AvgDeptSalary
FROM Employees
WHERE DepartmentID = (
    SELECT DepartmentID FROM Employees WHERE FirstName = 'Kavya'
);

--  Employees in depts with avg salary > 50000
SELECT * 
FROM Employees
WHERE DepartmentID IN (
    SELECT DepartmentID
    FROM Employees
    GROUP BY DepartmentID
    HAVING AVG(Salary) > 50000
);

--  Employees with same salary & dept as another employee
SELECT EmployeeID, FirstName
FROM Employees e
WHERE (Salary, DepartmentID) IN (
    SELECT Salary, DepartmentID
    FROM Employees
    GROUP BY Salary, DepartmentID
    HAVING COUNT(*) > 1
);

--  Employees earning more than dept avg
SELECT *
FROM Employees e
WHERE Salary > (
    SELECT AVG(Salary)
    FROM Employees
    WHERE DepartmentID = e.DepartmentID
);

--  Earliest join in dept
SELECT *
FROM Employees e
WHERE HireDate = (
    SELECT MIN(HireDate)
    FROM Employees
    WHERE DepartmentID = e.DepartmentID
);

-- joins
SELECT e.EmployeeID, e.FirstName, d.DepartmentName
FROM Employees e
INNER JOIN Department d ON e.DepartmentID = d.DepartmentID;

-- left join
SELECT e.EmployeeID, e.FirstName, d.DepartmentName
FROM Employees e
LEFT JOIN Department d ON e.DepartmentID = d.DepartmentID;

-- right join
SELECT d.DepartmentID, d.DepartmentName, e.FirstName
FROM Employees e
RIGHT JOIN Department d ON e.DepartmentID = d.DepartmentID;

-- cross join
SELECT e.FirstName, d.DepartmentName
FROM Employees e
CROSS JOIN Department d;

--  Employees in same dept
SELECT e1.FirstName AS Employee, e2.FirstName AS Colleague, e1.DepartmentID
FROM Employees e1
JOIN Employees e2 
  ON e1.DepartmentID = e2.DepartmentID 
 AND e1.EmployeeID <> e2.EmployeeID;
 
 select * from employees;
 
 ALTER TABLE Employees ADD ManagerID INT;
UPDATE Employees SET ManagerID = 101 WHERE EmployeeID IN (102,103);
UPDATE Employees SET ManagerID = 105 WHERE EmployeeID IN (106);
UPDATE Employees SET ManagerID = 108 WHERE EmployeeID IN (109);

select * from employees;

SELECT e.FirstName AS Employee, m.FirstName AS Manager
FROM Employees e
JOIN Employees m ON e.ManagerID = m.EmployeeID;

-- Employees with active departments
SELECT e.FirstName, d.DepartmentName
FROM Employees e
JOIN Department d 
    ON e.DepartmentID = d.DepartmentID
WHERE d.DepartmentID IN (
    SELECT DepartmentID FROM Department WHERE Status = 'Active'
);

-- Salary > dept avg (with dept name)
SELECT e.FirstName, e.Salary, d.DepartmentName
FROM Employees e
JOIN Department d ON e.DepartmentID = d.DepartmentID
WHERE e.Salary > (
    SELECT AVG(Salary)
    FROM Employees
    WHERE DepartmentID = e.DepartmentID
);

select * from employees;

SELECT d.DepartmentName, COUNT(e.EmployeeID) AS NumEmployees, AVG(e.Salary) AS AvgSalary
FROM Department d
LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID
GROUP BY d.DepartmentName;





