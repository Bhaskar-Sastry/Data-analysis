CREATE DATABASE ecommerce_db;
USE ecommerce_db;
CREATE TABLE customers (
    customer_id INT(11) PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(150) UNIQUE
);
CREATE TABLE products (
    product_id INT(11) PRIMARY KEY,
    product_name VARCHAR(200),
    price DECIMAL(10,2)
);
CREATE TABLE orders (
    order_id INT(11) PRIMARY KEY,
    customer_id INT(11),
    order_date DATE,
    FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
CREATE TABLE order_items (
    order_id INT(11),
    product_id INT(11),
    quantity INT(11),
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id)
        REFERENCES orders(order_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (product_id)
        REFERENCES products(product_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

select * from customers;
select * from order_items;
select * from orders;
select * from products;
/* Find the product with the highest price*/
SELECT product_name
FROM products
ORDER BY price DESC
LIMIT 1;
/*2. Find the customer who has made the most orders*/
SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    COUNT(o.order_id) AS total_orders
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
GROUP BY c.customer_id
ORDER BY total_orders DESC
LIMIT 1;
/*3. Find the product with the highest total revenue*/
SELECT 
    p.product_name,
    SUM(oi.quantity * p.price) AS total_revenue
FROM products p
JOIN order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.product_id
ORDER BY total_revenue DESC
LIMIT 1;

/*4. Find the top customer who ordered the most distinct products*/
SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    COUNT(DISTINCT oi.product_id) AS distinct_products
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
JOIN order_items oi
    ON o.order_id = oi.order_id
GROUP BY c.customer_id
ORDER BY distinct_products DESC
LIMIT 1;

/*5.Find the first order (earliest date) for customer "John Doe"*/
SELECT 
    MIN(o.order_date) AS first_order_date
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
WHERE CONCAT(c.first_name, ' ', c.last_name) = 'John Doe';
