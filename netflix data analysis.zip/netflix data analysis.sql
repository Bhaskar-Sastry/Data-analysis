create database netflix_data;
use netflix_data;
CREATE TABLE netflix (
    show_id VARCHAR(10) PRIMARY KEY,
    type VARCHAR(20),
    title VARCHAR(255),
    director VARCHAR(255),
    cast TEXT,
    country VARCHAR(100),
    date_added DATE,
    release_year INT,
    rating VARCHAR(10),
    duration VARCHAR(20),
    listed_in VARCHAR(255),
    description TEXT
);

DROP TABLE IF EXISTS netflix;
CREATE TABLE netflix (
    show_id VARCHAR(10) PRIMARY KEY,
    type VARCHAR(20),
    title VARCHAR(255),
    director VARCHAR(255),
    cast TEXT,
    country VARCHAR(100),
    date_added VARCHAR(50),   -- ✅ VARCHAR
    release_year INT,
    content_rating VARCHAR(10),
    duration VARCHAR(20),
    listed_in VARCHAR(255),
    description TEXT
);

select * from netflix;

select * from netflix order by show_id ASC;

SELECT COUNT(*) AS total_records
FROM netflix;

select type, COUNT(*) AS total_count
FROM netflix
GROUP BY type;

SELECT director, COUNT(*) AS total_content
FROM netflix
WHERE director IS NOT NULL
GROUP BY director
ORDER BY total_content DESC
LIMIT 1;

SELECT title, date_added
FROM netflix
WHERE date_added IS NOT NULL
ORDER BY date_added DESC
LIMIT 1;

SELECT type, MIN(release_year) AS min_release_year
FROM netflix
GROUP BY type;

SELECT country, COUNT(*) AS total_content
FROM netflix
WHERE country IS NOT NULL
GROUP BY country
ORDER BY total_content DESC
LIMIT 1;

SELECT title, duration
FROM netflix
WHERE type = 'Movie'
ORDER BY CAST(SUBSTRING_INDEX(duration, ' ', 1) AS UNSIGNED) DESC
LIMIT 1;

