use learndb;

Select * from myemp;

-- Math calculation
Select *,salary *0.20 as Bonus from myemp;

-- Inbuilt functions
Select *,Monthname(hire_date) as month_name from myemp;

Select first_name,last_name,
Concat(first_name," ",last_name) as full_name
	from myemp;
    
-- Case statements
Select * from myemp;
Select *, (CASE
			When salary > 18000 then "High_paid"
            When salary between 10000 and 18000 then "Avg_paid"
            else "Low_paid" END) as salary_cat
            from myemp;


select * from peopledata;

Select sum(CASE 
			when gender = "M" then 1 else 0  END) as Males,
		sum(Case 
			when gender = "F" then 1 else 0 END) as Females
            from peopledata;
            
	
            
            

