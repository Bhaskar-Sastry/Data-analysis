Create table mobiles
		(Brand	varchar(255),
        Color	varchar(255),
        Storage	smallint,
        Rating	float(2,1),
        Screen_size	float(3,2),
        Battery	smallint,
        Price decimal);
        
Select * from mobiles;

-- Find out no.of apple mobiles in the given data
Select count(*) from mobiles
	Where Brand = "Apple";
-- How many Brands are their
Select count(distinct Brand) from mobiles;
-- What is the Average price
Select Avg(price) from mobiles;
/*Create a column called price_category
 -- price > 80k -- "high"
 -- 25 - 80 -- "medium"
 -- <25k --- "low"
 Access 50th row and find what is price_category of it*/
 Select *, (Case
			when price> 80000 then "high"
            when price between 25000 and 80000 then "medium"
            else "low" END) as price_category
            from mobiles
            limit 1 offset 49;
 
 -- Retrieve the Mobile where color name starts with "B".
 Select * from mobiles
	where Color Like "B%";

Select Distinct * from mobiles;
-- Retrieve medium price_cat mobiles
Select *, (Case
			when price> 80000 then "high"
            when price between 25000 and 80000 then "medium"
            else "low" END) as price_category
            from mobiles
            Where price_category = "medium";

