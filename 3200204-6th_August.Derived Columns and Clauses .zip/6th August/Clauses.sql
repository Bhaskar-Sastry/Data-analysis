

-- How many mobiles are their in each Brand

Select Brand,count(*), Avg(price),min(price), max(price),sum(price)
 from mobiles
	Group by Brand;
    
Select Brand,Storage,Min(price) as min_price
	 from mobiles
     Group by Brand,Storage
     Order by min_price ASC;
     
-- Find out min price for only group size > 30
Select Brand,Storage,count(*), Min(price) as min_price
	 from mobiles
     Group by Brand,Storage
     Having count(*) > 30;
     
     
/* Find out avg price of mobiles with respective
	each Brand where the mobile rating > 4.0
    and the no.of mobiles in th Brand should > 15
    and order of resulatant table is based on Avg price*/
    
Select Brand, Avg(price) as Average_price
	from mobiles
    where rating > 4.0
    Group by Brand
    Having Count(Brand) > 15
    Order by Average_price DESC;
    
    
Select *, (Case
			when price> 80000 then "high"
            when price between 25000 and 80000 then "medium"
            else "low" END) as price_category
            from mobiles   
            group by price_category;
     
Select * from peopledata;

-- Find the Frequency of is_subscribed column
-- Find the Frequency of Gender colum
-- What is the Average purchase amount of is_subscribed = 1
/*What is the min rating WRT Gender and is_subscribed
	order the result based on is_subscribed column*/
-- Find out avg purchase amount WRT to each month.

