
Create database EcommercesDB;

Use EcommercesDB;

-- Products

Create table products(pid tinyint Primary key auto_increment,
				pname varchar(50) Not null,
                Category varchar(50) Not Null,
                Quatity smallint not null,
                unit_price decimal );
Select * from products;

Insert into products(pname,category,quatity,unit_price)
			values("Shirt","Fashion",200,1000),
				("Sun Screen","skin care",100,250),
                ("Mobiles","electronics",100,15000);
                
Describe products;


Create table customers(cid tinyint Primary Key auto_increment,
						name varchar(50) not null,
                        emailid varchar(100) Not null);
                        
Select * from customers;

Insert into customers(name,emailid) 
	values("Ved","V@gmail.com"),
		("Tej","t@gmail.com"),
        ("Pavan","P@gmail.com"),
        ("rishi","r@gmaiol.com");


Create table orders(oid tinyint Primary key auto_increment,
					pid tinyint,
                    cid tinyint,
                    quantity smallint,
                    total_price Decimal,
                    foreign key(pid) references products(pid) 
                    on update cascade on delete cascade,
                    foreign key(cid) references customers(cid)
                    on update cascade on delete cascade );
                    

Select * from orders;

Insert into orders(pid,cid,quantity,total_price)
	values(2,3,4,10000),
		(3,1,5,2133),
        (1,3,10,3214),
        (2,3,5,23123);

select * from products;
Update products set pid = 5
	where pid = 3;

