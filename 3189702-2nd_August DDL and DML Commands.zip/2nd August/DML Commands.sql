
-- DML Commands
-- Insert (add a row)
-- Update (update a value)
-- Delete (remove row from the table)

Select * from std_;

-- ADD a row
describe std_;

Alter table std_ drop column phone_number;
Alter table std_ drop column Picture;

-- General insert query
Insert into std_ values(1,"Ved",32,"V@gmail.com","ABC");

Select * from std_;

-- Specified order
INSERT into std_(email,address,student_id,name,age)
	Values("T@gmail.com","BB",2,"Tej",27);

-- NULL Values
Insert into std_ values(3,"Pavan",NULL,"p@gmail.co","DDD");

Insert into std_(student_id,name,email,address)
	Values(4,"Praven","praven@","ADC");
    
Insert into std_(student_id,name,email)
	Values(5,"Praven","praven@gmail");

-- Multiple rows

Insert into std_ values(6,"Raju",31,"R@gmail","AAA"),
						(7,"Sai",33,"S@gmail.com","BBB"),
                        (8,"Kalyan",29,"K@gmail.com","CCC");
                        

-- Update

set sql_safe_updates = 0;

Select * from std_;
-- updating age of Ved from 32 to 99
update std_ set age = 99
	where student_id= 1;
    
-- updating the Address of students to "AAAAAAA" where age> 30
Update std_ set address = "AAAAAAA" 
	where age> 30;
    
Update std_ set address = "BBBBBBBBBB";

-- Delete 
Select * from std_;

-- REmoving praveen details from table
Delete from std_ 
	where student_id = 4;
    
-- Remove students whose age is greater than 32

Delete from std_
	where age > 32;
    
Delete from std_;







