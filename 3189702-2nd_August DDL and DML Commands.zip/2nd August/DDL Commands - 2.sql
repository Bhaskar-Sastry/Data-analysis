use demo;
-- Rename 

Rename table students to std_;

-- Truncate

Select * from std_;



Truncate std_;
-- Drop 


Drop table std_;

Drop database demo;