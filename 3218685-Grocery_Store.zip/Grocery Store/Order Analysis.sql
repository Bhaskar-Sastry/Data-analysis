-- On which dates were the highest number of orders placed?

Select * from orders;

with cte_1 as (Select *,str_to_date(order_date,"%m/%d/%Y") as new_date 
from orders),

cte_2 as (Select new_date,count(*) as freq from cte_1
	group by new_date
    order by freq desc),
    
cte_3 as (Select *, dense_rank() over (order by freq desc) as drnk from 
cte_2)
Select * from cte_3
	where drnk = 1;
   
-- In Which most orders have placed
with cte_1 as (Select *,Monthname(str_to_date(order_date,"%m/%d/%Y")) as month 
from orders)

select month,count(*) as freq from cte_1
		group by month
        order by freq desc;
        
-- how many days the since the order as placed
with cte_1 as (Select *,str_to_date(order_date,"%m/%d/%Y") as new_date,curdate() as today
from orders)

Select *,concat(datediff(today,new_date)," days") as days_passed from cte_1;

-- In Which Quater most orders placed
with cte_1 as (Select *,Quarter(str_to_date(order_date,"%m/%d/%Y"))  as quater
from orders)
Select quater,count(*) from cte_1
	group by quater
    order by count(*) desc;


