/**Customer Analysis:*/
-- How many customers are there in total?
Select * from customers;
Select count(*) from customers;

-- What are the top 5 most common customer names?
Select cust_name,count(*) as freq from customers
	Group by cust_name
    order by freq desc
    limit 5;
    
-- What is the average number of orders per customer?

with cte_1 as (Select cust_id,cust_name,count(*) as freq from customers
	Inner Join orders
    using (cust_id)
    group by cust_id,cust_name)
    
Select concat(round(avg(freq),1),"%") as average_order_per_customer from cte_1;

Select * from customers;

-- Calculate the percentage of cutomers from each city

with cte_1 as (Select *,substring_index(substring_index(address,",",2),",",-1) as city from 
customers),

cte_2 as (Select city,count(*) as freq
	from cte_1
    group by city),

cte_3 as (select count(*) as total from customers)

Select cte_2.city,concat(round(freq/cte_3.total *100),"%") as percentage from cte_2,cte_3;



