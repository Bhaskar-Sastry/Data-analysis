-- Product Analysis: 
-- How many products are there in each category?
Select cat_name,count(*) as freq from products
	INNER JOIN Categories
		using (cat_id)
        Group by cat_id,cat_name;

-- What is the average price of products in each category?
Select cat_name,avg(price) as average_price from products
	INNER JOIN Categories
		using (cat_id)
        Group by cat_id,cat_name;

-- Which supplier provides the most products?
with cte_1 as (Select sup_name,count(*) as freq from products
	INNER JOIN supplier
		using (sup_id) 
        group by sup_id,sup_name
        order by freq desc),
	
cte_2 as (Select *,dense_rank() over(order by freq desc) as drnk 
from cte_1)
Select * from cte_2 
	where drnk = 1;