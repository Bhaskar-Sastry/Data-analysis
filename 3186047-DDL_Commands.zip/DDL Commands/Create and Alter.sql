

-- DDL Commands

-- Create

Create database demo;

Create database if not exists demo;

-- define database which you want to work

use demo;

-- Create tables

Create table students(Sid tinyint unique Not null,
					Name varchar(255) Not null,
                    Age tinyint check(age>18),
                    email varchar(255) unique not null,
                    phone_number char(10) unique not null,
                    Address varchar(255) Default "Unknown",
                    picture blob Not null);
                    
describe students;

-- Alter 

-- Add column

Select * from students;

ALter table students add column about text;

-- change datatype

Describe students;

Alter table students modify column  sid smallint ;

-- change column name 

Alter table students change column sid student_id smallint;


-- Drop a column

Alter table students drop column about;

-- drop a constraint

Alter table students Drop constraint email;

-- Add a constraint

Alter table students add constraint uni_email unique(email);

-- Drop a check constraint

Alter table students drop constraint students_chk_1;

