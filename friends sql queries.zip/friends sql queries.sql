CREATE DATABASE friends_db;
USE friends_db;
CREATE TABLE friends (id INTEGER PRIMARY KEY AUTO_INCREMENT,name TEXT,birthday DATE);
desc friends;
INSERT INTO friends (name, birthday)VALUES ('John Doe', '1996-08-30');
SELECT * FROM friends;
INSERT INTO friends (name, birthday)VALUES('Rahul Sharma', '1997-05-12'),('Anita Verma', '1998-11-20');
UPDATE friends SET name = 'Luis Johnson' WHERE name = 'John Doe';
UPDATE friends SET name = 'Luis Johnson'WHERE id = 1;
DELETE FROM friends WHERE name = 'Luis Johnson';
select * from  friends;
DELETE FROM friends WHERE name = 'Luis Johnson';
DELETE FROM friends WHERE name = 'Luis';

SELECT * FROM friends;
SELECT * FROM friends;
DELETE FROM friends WHERE id = 1;
