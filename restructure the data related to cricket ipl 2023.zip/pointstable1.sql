create database cricket;
use cricket;
CREATE TABLE Tournament (
    Team1 VARCHAR(50),
    Team2 VARCHAR(50),
    Winner VARCHAR(50)
);


INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'CSK', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'MI', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'RCB', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'CSK', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'MI', NULL);
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'RCB', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'CSK', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'MI', NULL);
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'RCB', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'CSK', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'CSK', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'MI', NULL);
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('MI', 'RCB', 'MI');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('RCB', 'MI', 'RCB');
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ('CSK', 'RCB', 'CSK');
select * from tournament;

WITH cte_1 AS (
    SELECT 
        Team1 AS team,
        CASE 
            WHEN Team1 = winner THEN 1 ELSE 0 
        END AS w,
        CASE 
            WHEN winner IS NULL THEN 1 ELSE 0 
        END AS d
    FROM tournament

    UNION ALL

    SELECT 
        Team2 AS team,
        CASE 
            WHEN Team2 = winner THEN 1 ELSE 0 
        END AS w,
        CASE 
            WHEN winner IS NULL THEN 1 ELSE 0 
        END AS d
    FROM tournament
)
SELECT 
    team,
    COUNT(*) AS matches,
    SUM(w) AS won,
    COUNT(*) - SUM(w) - SUM(d) AS lost,
    SUM(d) AS draw,
    SUM(w) * 2 + SUM(d) * 1 AS points
FROM cte_1
GROUP BY team;
    
select * from tournament;
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("GT","SRH","SRH");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("GT","CSK","GT");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("GT","LSG","GT");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("GT","MI","GT");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("CSK","LSG","CSK");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("CSK","MI","CSK");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("LSG","MI","LSG");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("RR","RCB","RR");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("KKR","PBKS","KKR");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("DC","SRH","SRH");
INSERT INTO Tournament (Team1, Team2, Winner) VALUES ("GT","SRH","SRH");

CREATE VIEW pointable AS
WITH cte_1 AS (
    SELECT 
        Team1 AS team,
        CASE 
            WHEN Team1 = winner THEN 1 ELSE 0 
        END AS w,
        CASE 
            WHEN winner IS NULL THEN 1 ELSE 0 
        END AS d
    FROM tournament

    UNION ALL

    SELECT 
        Team2 AS team,
        CASE 
            WHEN Team2 = winner THEN 1 ELSE 0 
        END AS w,
        CASE 
            WHEN winner IS NULL THEN 1 ELSE 0 
        END AS d
    FROM tournament
)
SELECT 
    team,
    COUNT(*) AS matches,
    SUM(w) AS won,
    COUNT(*) - SUM(w) - SUM(d) AS lost,
    SUM(d) AS draw,
    SUM(w) * 2 + SUM(d) AS points
FROM cte_1
GROUP BY team;
INSERT INTO Tournament(Team1, Team2, Winner) values("LSG","KKR","LSG");

select * from pointable;
/*SHOW CREATE VIEW pointable;*/
DELETE FROM pointable WHERE Team2 = 'KKR';

drop view pointables;
update pointable  set points =200 where team="SRH";

